from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

# Dictionary to store video file IDs with unique codes
file_links = {}

BOT_TOKEN = "7747897613:AAFISuUk9QZzxd1kbFgD8Qb_T-CACqyggpw"  # ✅ आपका Token

# /start command to retrieve video via unique link
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if args and args[0] in file_links:
        file_id = file_links[args[0]]
        await update.message.reply_video(file_id)
    else:
        await update.message.reply_text("📥 मुझे वीडियो भेजो या वैध लिंक से एक्सेस करो।")

# Video upload handler
async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.video:
        video = update.message.video
        code = str(video.file_unique_id)[-6:]
        file_links[code] = video.file_id

        bot_username = (await context.bot.get_me()).username
        link = f"https://t.me/{bot_username}?start={code}"
        await update.message.reply_text(f"✅ आपका वीडियो लिंक:\n🔗 {link}")

# Main function to start the bot
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.VIDEO, handle_video))
    app.run_polling()

if __name__ == "__main__":
    main()